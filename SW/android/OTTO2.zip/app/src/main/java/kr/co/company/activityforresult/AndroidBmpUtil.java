package kr.co.company.activityforresult;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

import android.app.Activity;
import android.graphics.Bitmap;


public class AndroidBmpUtil extends Activity{
	
	private final int BMP_WIDTH_OF_TIMES = 4;
	private final int BYTE_PER_PIXEL = 3;

	/**
	 * Android Bitmap Object to Window's v3 24bit Bmp Format File
	 * @param orgBitmap
	 * @param filePath
	 * @return file saved result
	 */
	public boolean save(Bitmap orgBitmap, String filePath){
		
		if(orgBitmap == null){
			return false;
		}

		if(filePath == null){
			return false;
		}

		boolean isSaveSuccess = true;

		//image size
		int width = orgBitmap.getWidth();
		int height = orgBitmap.getHeight();

		//image dummy data size
		//reason : bmp file's width equals 4's multiple
		int dummySize = 0;
		byte[] dummyBytesPerRow = null;
		boolean hasDummy = false;
		if(isBmpWidth4Times(width)){
			hasDummy = true;
			dummySize = BMP_WIDTH_OF_TIMES - (width % BMP_WIDTH_OF_TIMES);
			dummyBytesPerRow = new byte[dummySize * BYTE_PER_PIXEL];
			for(int i = 0; i < dummyBytesPerRow.length; i++){
				dummyBytesPerRow[i] = (byte)0xFF;
			}
		}
		int index =0;					//index
		int z =width * height-1;	//index
		double a;
		int w = 40;//32			//number of LED Width  of output
		int h = 107;//125;//257;//125   //				Height of output
		float angle = 0;
		int[] pixels = new int[width * height];
		int[] imageData = new int[width * height];
		int[] imageDataEdit = new int[w * h];
		int [] imageDataNew = new int[w * h];
		int imageSize = w*h*BYTE_PER_PIXEL;		
//		int imageSize = pixels.length * BYTE_PER_PIXEL + (h * dummySize * BYTE_PER_PIXEL);
		int imageDataOffset = 0x36;
		int fileSize = imageSize + imageDataOffset;
		
		//Android Bitmap Image Data
		orgBitmap.getPixels(pixels, 0, width, 0, 0, width, height);
		for (int y=0; y < height; y++){
			for (int x=0; x < width; x++) {
				imageData[z--] = pixels[index++];
			}
		}
		index = 0;
		orgBitmap.setPixels(imageData, 0, width, 0, 0, width, height);

		for(a=3.46;a<=3.46*w;a+=3.46){
			for( angle = 0; angle <= 2*Math.PI; )//		for( angle = 0; angle <= 2*Math.PI; )
			{
				int x = (int)(java.lang.Math.cos(angle)*(height-a)/2+height/2);
				int y = (int)(java.lang.Math.sin(angle)*(width-a)/2+width/2);
				
				imageDataEdit[index++] = orgBitmap.getPixel(x,y); // a/r/g/b
				
				angle+=Math.PI/53.5;//62;//128;//62
			}
		}

		index = 0;
		
		//rotate "imageDataEdit" 90 degrees clock wise
		for (int y =0; y < h; y++){
			for(int x=0; x < w; x++) {
			imageDataNew[index++] = imageDataEdit[(h*(w-x-1)+y)];  //imageData[(h*(w-1)-h*x)+y];
			}
		}
		//ByteArrayOutputStream baos = new ByteArrayOutputStream(fileSize);
		ByteBuffer buffer = ByteBuffer.allocate(fileSize);

		try {
			/**
			 * BITMAP FILE HEADER Write Start
			 **/
			buffer.put((byte)0x42);
			buffer.put((byte)0x4D);

			//size
			buffer.put(writeInt(fileSize));

			//reserved
			buffer.put(writeShort((short)0));
			buffer.put(writeShort((short)0));
		
			//image data start offset
			buffer.put(writeInt(imageDataOffset));
		
			/** BITMAP FILE HEADER Write End */

			//*******************************************
		
			/** BITMAP INFO HEADER Write Start */
			//size
			buffer.put(writeInt(0x28));
		
			//width, height
			buffer.put(writeInt(w));
			buffer.put(writeInt(h));
		
			//planes
			buffer.put(writeShort((short)1));
		
			//bit count
			buffer.put(writeShort((short)24));
		
			//bit compression
			buffer.put(writeInt(0));
		
			//image data size
			buffer.put(writeInt(imageSize));
		
			//horizontal resolution in pixels per meter
			buffer.put(writeInt(0));
		
			//vertical resolution in pixels per meter (unreliable)
			buffer.put(writeInt(0));
		
			//컬러 ?��?�� ?���?
			buffer.put(writeInt(0));
		
			//중요?���? ?��?��?��?�� ?��
			buffer.put(writeInt(0));

			/** BITMAP INFO HEADER Write End */
 
			int row = h;
			int col = w;
			int startPosition = 0;
			int endPosition = 0;
 
			while( row > 0 ){
 	
				startPosition = (row - 1) * col;
				endPosition = row * col;
 		
				for(int i = startPosition; i < endPosition; i++ ){
					buffer.put(write24BitForPixcel(imageDataNew[i]));

					if(hasDummy){
						if(isBitmapWidthLastPixcel(w, i)){
							buffer.put(dummyBytesPerRow);
						}  			
					}
				}
	
				row--;
			}
 
			FileOutputStream fos = new FileOutputStream(filePath);
			fos.write(buffer.array());
			fos.close();
	
		} catch (IOException e1) {
			e1.printStackTrace();
			isSaveSuccess = false;
		}
		orgBitmap.setPixels(pixels, 0, width, 0, 0, width, height);
		return isSaveSuccess;
	}

	/**
	 * Is last pixel in Android Bitmap width  
	 * @param width
	 * @param i
	 * @return
	 */
	private boolean isBitmapWidthLastPixcel(int width, int i) {
		return i > 0 && (i % (width - 1)) == 0;
	}

	/**
	 * BMP file is a multiples of 4?
	 * @param width
	 * @return
	 */
	private boolean isBmpWidth4Times(int width) {
		return width % BMP_WIDTH_OF_TIMES > 0;
	}
	
	/**
	 * Write integer to little-endian 
	 * @param value
	 * @return
	 * @throws IOException
	 */
	private byte[] writeInt(int value) throws IOException {
		byte[] b = new byte[4];
 	
		b[0] = (byte)(value & 0x000000FF);
		b[1] = (byte)((value & 0x0000FF00) >> 8);
		b[2] = (byte)((value & 0x00FF0000) >> 16);
		b[3] = (byte)((value & 0xFF000000) >> 24);
  
		return b;
	}
 
	/**
	 * Write integer pixel to little-endian byte array
	 * @param value
	 * @return
	 * @throws IOException
	 */
	private byte[] write24BitForPixcel(int value) throws IOException {
		byte[] b = new byte[3];
 	
		b[0] = (byte)(value & 0x000000FF);
		b[1] = (byte)((value & 0x0000FF00) >> 8);
		b[2] = (byte)((value & 0x00FF0000) >> 16);
  
		return b;
	}

	/**
	 * Write short to little-endian byte array
	 * @param value
	 * @return
	 * @throws IOException
	 */
	private byte[] writeShort(short value) throws IOException {
		byte[] b = new byte[2];
 	
		b[0] = (byte)(value & 0x00FF);
		b[1] = (byte)((value & 0xFF00) >> 8);
		
		return b;
	}
}
