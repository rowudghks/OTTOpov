package kr.co.company.activityforresult;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
 
 
public class IntroActivity extends Activity {
	
	Handler h;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.intro_activity);
         
        h = new Handler();
        h.postDelayed(irun, 2222);
    }
    Runnable irun = new Runnable() {
    	public void run() {
    		Intent i = new Intent(IntroActivity.this, MainActivity.class);
    		startActivity(i);
    		finish();
    		overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
    	}
    };
    @Override
    public void onBackPressed(){
    	super.onBackPressed();
    	h.removeCallbacks(irun);
    }
}