package kr.co.company.activityforresult;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;


import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ListForActivity extends ListActivity {
	private AlertDialog hDialog = null;
	static String FileName = null;
	static String Temp = null;
	public String dirName;
	public String[] files = null;
	private List<String> bmps = new ArrayList<String>();
	private TextView textbox;
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listmain);
		Typeface typeface = Typeface.createFromAsset(getAssets(), "MyriadPro-Regular.otf");
	    textbox = (TextView)findViewById(R.id.textView1);
	    textbox.setTypeface(typeface);
		files = getFilesList();

		if (files != null) {

			for (int i = 0; i < files.length; i++) {
				// Add filename to service playlist
				bmps.add(files[i]);
			}

		}
		setListAdapter(new ArrayAdapter<String>(this,R.layout.listname, bmps));
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		Temp = Environment.getExternalStorageDirectory().getAbsolutePath()+"/otto/";
		FileName = bmps.get(position);
		hDialog = createDialog();
        hDialog.show();
	}
	private AlertDialog createDialog() {
        AlertDialog.Builder ab = new AlertDialog.Builder(this);
        ab.setTitle("전송하시겠습니까?");
        ab.setMessage("  전송에는  대략 3분정도의 시간이 \n  걸릴 수 있습니다.");
        ab.setCancelable(false);
        ab.setIcon(getResources().getDrawable(R.drawable.ic_launcher));
          
        ab.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
        		Toast.makeText(getApplicationContext(),FileName + "\n전송 시작",Toast.LENGTH_SHORT).show();
        		SubActivity.mProgressDialog.show();
        	    /** ProgressBar starts its execution */
        		SubActivity.mProgressbarAsync.execute();
                setDismiss(hDialog);
                finish();
            }
        });
          
        ab.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                setDismiss(hDialog);
            }
        });
          
        return ab.create();
    }
	public String[] getFilesList() {
		String fileList[] = null;

		String bmpState = Environment.getExternalStorageDirectory().getAbsolutePath()+"/otto/";
		if (bmpState.contentEquals(Environment.getExternalStorageDirectory().getAbsolutePath()+"/otto/")) {
			dirName = Environment.getExternalStorageDirectory().getAbsolutePath()+"/otto/";
			File dir = new File(dirName);
			FilenameFilter filter = new FilenameFilter() {
				public boolean accept(File file, String name) {
					return (name.endsWith(".bmp"));
				}
			};
			fileList = dir.list(filter);
			return fileList;
		}
		return null;

	}
    private void setDismiss(Dialog dialog){
        if(dialog != null && dialog.isShowing())
            dialog.dismiss();
    }
}