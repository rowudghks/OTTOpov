package kr.co.company.activityforresult;

import java.io.File;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener
{
  private static final int PICK_FROM_CAMERA = 0;
  private static final int PICK_FROM_ALBUM = 1;
  private static final int CROP_FROM_CAMERA = 2;
  static final int GET_STRING = 1;
  private Uri mImageCaptureUri;
  private ImageView mPhotoImageView;
  private Button mButton;
  private Bitmap photo;
  private TextView textbox;
  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    mButton = (Button) findViewById(R.id.select);
    findViewById(R.id.butV).setOnClickListener(mClickListener);
	findViewById(R.id.butH).setOnClickListener(mClickListener);
	findViewById(R.id.butR).setOnClickListener(mClickListener);
	findViewById(R.id.butL).setOnClickListener(mClickListener);
	findViewById(R.id.save).setOnClickListener(mClickListener);
    mPhotoImageView = (ImageView) findViewById(R.id.imageView);
    mButton.setOnClickListener(this);
    Typeface typeface = Typeface.createFromAsset(getAssets(), "MyriadPro-Regular.otf");
    textbox = (TextView)findViewById(R.id.textView1);
    textbox.setTypeface(typeface);
    Button btnCallMain = (Button) findViewById(R.id.next);
	btnCallMain.setOnClickListener(new OnClickListener() {
		public void onClick(View v)
		{
			Intent intent =  new Intent(MainActivity.this, SubActivity.class);    
		     startActivity(intent);
		}
	});
  }

  /**
   * ī�޶󿡼� �̹��� ��������
   */
  private void doTakePhotoAction()
  {
    /*
     * ���� �غ���
     * http://2009.hfoss.org/Tutorial:Camera_and_Gallery_Demo
     * http://stackoverflow.com/questions/1050297/how-to-get-the-url-of-the-captured-image
     * http://www.damonkohler.com/2009/02/android-recipes.html
     * http://www.firstclown.us/tag/android/
     */
 
    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
 
    // �ӽ÷� ����� ������ ��θ� ����
    String url = "tmp_" + String.valueOf(System.currentTimeMillis()) + ".bmp";
    mImageCaptureUri = Uri.fromFile(new File(Environment.getExternalStorageDirectory(), url));
 
    intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, mImageCaptureUri);
    // Ư����⿡�� ������ ������ϴ� ������ �־� ������ �ּ�ó�� �մϴ�.
    //intent.putExtra("return-data", true);
    startActivityForResult(intent, PICK_FROM_CAMERA);
  }

  /**
   * �ٹ����� �̹��� ��������
   */
  private void doTakeAlbumAction()
  {
	  Intent intent = new Intent(Intent.ACTION_PICK);
	  intent.setData(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
	  intent.setType("image/*");
	  //intent.setType(android.provider.MediaStore.Images.Media.CONTENT_TYPE);
	  startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_FROM_ALBUM);
  }
  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data)
  {
    if(resultCode != RESULT_OK)
    {
      return;
    }
 
    switch(requestCode)
    {
      case CROP_FROM_CAMERA:
      {
        // ũ���� �� ������ �̹����� �Ѱ� �޽��ϴ�.
        // �̹����信 �̹����� �����شٰų� �ΰ����� �۾� ���Ŀ�
        // �ӽ� ������ �����մϴ�.
        final Bundle extras = data.getExtras();
 
        if(extras != null)
        {
          photo = extras.getParcelable("data");
          mPhotoImageView.setImageBitmap(photo);
          textbox.setText("IMAGE EDIT");
          
        }
 
        // �ӽ� ���� ����
        File f = new File(mImageCaptureUri.getPath());
        if(f.exists())
        {
          f.delete();
        }
 
        break;
      }
 
      case PICK_FROM_ALBUM:
      {
        // ������ ó���� ī�޶�� �����Ƿ� �ϴ�  break���� �����մϴ�.
        // ���� �ڵ忡���� ���� �ո����� ����� �����Ͻñ� �ٶ��ϴ�.
 
        mImageCaptureUri = data.getData();
      }
 
      case PICK_FROM_CAMERA:
      {
        // �̹����� ������ ������ ���������� �̹��� ũ�⸦ �����մϴ�.
        // ���Ŀ� �̹��� ũ�� ���ø����̼��� ȣ���ϰ� �˴ϴ�.
 
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(mImageCaptureUri, "image/*");
        intent.putExtra("outputX", 320);
        intent.putExtra("outputY", 320);
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("scale", true);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, CROP_FROM_CAMERA);
 
        break;
      }
    }
  }
 
  @Override
  public void onClick(View v)
  {
    DialogInterface.OnClickListener cameraListener = new DialogInterface.OnClickListener()
    {
      @Override
      public void onClick(DialogInterface dialog, int which)
      {
        doTakePhotoAction();
      }
    };
 
    DialogInterface.OnClickListener albumListener = new DialogInterface.OnClickListener()
    {
      @Override
      public void onClick(DialogInterface dialog, int which)
      {
        doTakeAlbumAction();
      }
    };
 
    DialogInterface.OnClickListener cancelListener = new DialogInterface.OnClickListener()
    {
      @Override
      public void onClick(DialogInterface dialog, int which)
      {
        dialog.dismiss();
      }
    };
 
    new AlertDialog.Builder(this)
      .setTitle("업로드할 이미지 선택")
      .setPositiveButton("사진촬영", cameraListener)
      .setNeutralButton("앨범선택", albumListener)
      .setNegativeButton("취소", cancelListener)
      .show();
  }

  Button.OnClickListener mClickListener = new View.OnClickListener() {
		//public Bitmap originalImg = BitmapFactory.decodeResource(getResources(),R.drawable.topinfo_110);
		//private Bitmap originalImg;// = BitmapFactory.decodeResource(getResources(),R.drawable.topinfo_110);
			  public void onClick(View v) {			
				  if(null!=photo){
					int x = 1, y = 1;
					int count;
					switch (v.getId()){
					case R.id.butV:
						Matrix sideInversion = new Matrix();
						x=x*(-1);
						sideInversion.setScale(x, 1);
						Bitmap sideInversionImg = Bitmap.createBitmap(photo, 0, 0,photo.getWidth(), 
								photo.getHeight(), sideInversion,true);
						photo = sideInversionImg;
						break;
					case R.id.butH:
						Matrix updownInversion = new Matrix();
						y=y*(-1);
						updownInversion.setScale(1, y);
						Bitmap updownInversionImg = Bitmap.createBitmap(photo, 0, 0,photo.getWidth(),
								photo.getHeight(), updownInversion,true);
						photo = updownInversionImg;
						break;
					case R.id.butR:
						Matrix rightRotation = new Matrix();
						rightRotation.postScale(photo.getWidth(),photo.getHeight());
						rightRotation.setRotate(90);
						Bitmap rightRotationImg = Bitmap.createBitmap(photo, 0, 0,photo.getWidth(),
								photo.getHeight(), rightRotation,true);
						photo = rightRotationImg;
						break;
					case R.id.butL:
						Matrix leftRotation = new Matrix();
						leftRotation.postScale(photo.getWidth(),photo.getHeight());
						leftRotation.setRotate(-90);
						Bitmap leftRotationImg = Bitmap.createBitmap(photo, 0, 0,photo.getWidth(),
								photo.getHeight(), leftRotation,true);
						photo = leftRotationImg;	
						break;
					case R.id.save:
						try {
							File saveDir = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/otto/");
							saveDir.mkdir();
							String name = "FRAME";
							String format = String.format("%%0%dd", 3);
							
							for (count =0; count<1000; count++) {
							String BmpPath = saveDir.getAbsolutePath() + ("/" + name + String.format(format, count) +".bmp");
							File files = new File(BmpPath);
							if(files.exists()==false) {break;}
							}

							String BmpPath = saveDir.getAbsolutePath() + ("/" + name + String.format(format, count) +".bmp");
							BitmapDrawable imgv = (BitmapDrawable)((ImageView) findViewById(R.id.imageView)).getDrawable();
							Bitmap testBitmap = imgv.getBitmap();
							AndroidBmpUtil bmpUtil = new AndroidBmpUtil();

							File files = new File(BmpPath);
							bmpUtil.save(testBitmap, BmpPath);
							count = 0;
							Toast.makeText(getApplicationContext(),"저장 완료", Toast.LENGTH_SHORT).show();     
					     }catch(Exception e) { Toast.makeText(getApplicationContext(), "저장 에러", Toast.LENGTH_SHORT).show();}
						
						break;
					}
					mPhotoImageView.setImageBitmap(photo);
				 }
				 
				  else{
						switch (v.getId()){
						case R.id.butV:
							new AlertDialog.Builder(MainActivity.this)
				             .setMessage("이미지를 선택하지 않았습니다.\n 이미지를 선택하세요.")
				             .setPositiveButton("닫기", new DialogInterface.OnClickListener() {
				                    public void onClick(DialogInterface dialog, int whichButton) {
				                    }
				             })
				             .show();
							break;
						case R.id.butH:
							new AlertDialog.Builder(MainActivity.this)
				             .setMessage("이미지를 선택하지 않았습니다.\n 이미지를 선택하세요.")
				             .setPositiveButton("닫기", new DialogInterface.OnClickListener() {
				                    public void onClick(DialogInterface dialog, int whichButton) {
				                    }
				             })
				             .show();
							
							break;
						case R.id.butR:
							new AlertDialog.Builder(MainActivity.this)
				             .setMessage("이미지를 선택하지 않았습니다.\n 이미지를 선택하세요.")
				             .setPositiveButton("닫기", new DialogInterface.OnClickListener() {
				                    public void onClick(DialogInterface dialog, int whichButton) {
				                    }
				             })
				             .show();
							
							break;
						case R.id.butL:
							new AlertDialog.Builder(MainActivity.this)
				             .setMessage("이미지를 선택하지 않았습니다.\n 이미지를 선택하세요.")
				             .setPositiveButton("닫기", new DialogInterface.OnClickListener() {
				                    public void onClick(DialogInterface dialog, int whichButton) {
				                    }
				             })
				             .show();
						
							break;
							
						case R.id.save:
							new AlertDialog.Builder(MainActivity.this)
				             .setMessage("이미지를 선택하지 않았습니다.\n 이미지를 선택하세요.")
				             .setPositiveButton("닫기", new DialogInterface.OnClickListener() {
				                    public void onClick(DialogInterface dialog, int whichButton) {
				                    }
				             })
				             .show();
						
							break;
							
						}
					 }
		  
			  }
		  };
		}
