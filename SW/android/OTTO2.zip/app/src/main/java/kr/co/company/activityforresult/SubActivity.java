package kr.co.company.activityforresult;



import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


public class SubActivity extends Activity 
{	

    static ProgressDialog mProgressDialog ;
    static MyTask mProgressbarAsync;
    private File file;
	// Message types sent from the BluetoothService Handler
	public static final int MESSAGE_STATE_CHANGE = 1;
	public static final int MESSAGE_READ = 2;
	public static final int MESSAGE_WRITE = 3;
	public static final int MESSAGE_DEVICE_NAME = 4;
	public static final int MESSAGE_TOAST = 5;
	private TextView textbox;

	// Key names received from the BluetoothService Handler
	public static final String DEVICE_NAME = "device_name";
	public static final String TOAST = "toast";

	// Intent request codes
	private static final int REQUEST_CONNECT_DEVICE = 1;
	private static final int REQUEST_ENABLE_BT = 2;

	// Layout Views
	private EditText mOutEditText;

	// Toolbar
	private Button mToolbarConnectButton;
	private Button mToolbarDisconnectButton;
	private Button mToolbarPauseButton = null, mToolbarPlayButton;

	// Name of the connected device
	private String mConnectedDeviceName = null;
	// Array adapter for the conversation thread
	private ArrayAdapter<String> mConversationArrayAdapter;
	// String buffer for outgoing messages
	private StringBuffer mOutStringBuffer;
	// Local Bluetooth adapter
	private BluetoothAdapter mBluetoothAdapter = null;
	// Member object for the Bluetooth services
	private BluetoothChatService mBluetoothService = null;

	// State variables
	private boolean paused = false;
	private boolean connected = false;

	/**
	 * @category Activity
	 */
	/*
	 * (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.bluetooth);
		Typeface typeface = Typeface.createFromAsset(getAssets(), "MyriadPro-Regular.otf");
	    textbox = (TextView)findViewById(R.id.textView1);
	    textbox.setTypeface(typeface);
		//		mSendTextContainer = findViewById(R.id.send_text_container);
	    Button btnc = (Button) findViewById(R.id.button_cancel3);
		btnc.setOnClickListener(new OnClickListener() {
			public void onClick(View v)
			{
				Intent intent =  new Intent(SubActivity.this, MainActivity.class);    
			     startActivity(intent);
			     finish();
			}
		});
		mToolbarConnectButton = (Button) findViewById(R.id.toolbar_btn_connect);
		mToolbarConnectButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				startDeviceListActivity();
			}
		});

		mToolbarDisconnectButton = (Button) findViewById(R.id.toolbar_btn_disconnect);
		mToolbarDisconnectButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				disconnectDevices();
			}
		});

		mToolbarPauseButton = (Button) findViewById(R.id.toolbar_btn_pause);
		mToolbarPauseButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				//				paused = true;
				//				onPausedStateChanged();
				sendMessage("0");
			}
		});

        /** Creating a progress dialog window */
        mProgressDialog = new ProgressDialog(this);
        
        /** Close the dialog window on pressing back button */
		mProgressDialog.setCancelable(false);
		
		/** Setting a horizontal style progress bar */
		mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		
		/** Setting a message for this progress dialog
		 * Use the method setTitle(), for setting a title 
		 * for the dialog window
		 *  */		
		mProgressDialog.setMessage("OTTO Uploading ...");

		mToolbarPlayButton = (Button) findViewById(R.id.toolbar_btn_play);
		mToolbarPlayButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {				
				if (mBluetoothService.getState() != BluetoothChatService.STATE_CONNECTED) {
					Toast.makeText(getApplicationContext(), "BT NOT CON", Toast.LENGTH_SHORT).show();
					return;
				}
				else{
					mProgressbarAsync = new MyTask();
					Intent intent =  new Intent(SubActivity.this, ListForActivity.class);    
				     startActivity(intent);
				}}
		});

		// Get local Bluetooth adapter
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

		// If the adapter is null, then Bluetooth is not supported
		//    if (mBluetoothAdapter == null) {
		//        Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
		//        finish();
		//    }
	}
	  
	    
//	public void startdialog() {
//	mProgressDialog.show();
//	
//	/** Creating an instance of ProgressBarAsync */
//    mProgressbarAsync = new MyTask();
//    
//    /** ProgressBar starts its execution */
//    mProgressbarAsync.execute();
///** Show the progress dialog window */
//	}
	private void startDeviceListActivity() {
		Intent serverIntent = new Intent(this, DeviceListActivity.class);
		startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
	}
	@Override
	public void onStart() {
		super.onStart();
		// If BT is not on, request that it be enabled.
		// setupUserInterface() will then be called during onActivityResult
		if (!mBluetoothAdapter.isEnabled()) {
			Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
			// Otherwise, setup the Bluetooth session
		} else {
			if (mBluetoothService == null) setupUserInterface();
		}
	}

	private void setupUserInterface() 
	{
		// Initialize the array adapter for the conversation thread
		mConversationArrayAdapter = new ArrayAdapter<String>(this, R.layout.message);
		ListView mConversationView = (ListView) findViewById(R.id.in);
		mConversationView.setAdapter(mConversationArrayAdapter);

		// Initialize the compose field with a listener for the return key
		mOutEditText = (EditText) findViewById(R.id.edit_text_out);
		mOutEditText.setOnEditorActionListener(mWriteListener);

		// Initialize the send button with a listener that for click events
		Button mSendButton = (Button) findViewById(R.id.button_send);
		mSendButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Send a message using content of the edit text widget
				TextView view = (TextView) findViewById(R.id.edit_text_out);
				String message = view.getText().toString();
				sendMessage(message);
			}
		});

		// Initialize the BluetoothService to perform Bluetooth connections
		mBluetoothService = new BluetoothChatService(mHandler);

		// Initialize the buffer for outgoing messages
		mOutStringBuffer = new StringBuffer("");
	}

	@Override
	public void onDestroy() 
	{
		super.onDestroy();
		
		if (mBluetoothService != null) 
		{
			mBluetoothService.stop();
		}
	}

	/**
	 * Sends a .
	 *
	 * @param  A string of text to send.
	 */
	private void sendMessage(String message) {
		// Check that we're actually connected before trying anything
		if (mBluetoothService.getState() != BluetoothChatService.STATE_CONNECTED) {
			Toast.makeText(getApplicationContext(), "BT NOT CON", Toast.LENGTH_SHORT).show();
			return;
		}
	    
		// Check that there's actually something to send
		if (message.length() > 0) {
			message += "\n";
			// Get the message bytes and tell the BluetoothService to write
			byte[] send = message.getBytes();
			mBluetoothService.write(send);

			// Reset out string buffer to zero and clear the edit text field
			mOutStringBuffer.setLength(0);
			mOutEditText.setText(mOutStringBuffer);
		}
	}
	class MyTask extends AsyncTask<Void, Integer, Void> {

		@Override
		protected void onPreExecute() {
    		super.onPreExecute();
    	}

		/**********************************************************************************************************/
		protected Void doInBackground(Void... params) {
			try {
			    file = new File(ListForActivity.Temp + ListForActivity.FileName);
			    FileInputStream fis = new FileInputStream(file);
			    
			    ByteArrayOutputStream bos = new ByteArrayOutputStream();
			    byte[] buf = new byte[64];
			
			    for (int readNum; (readNum = fis.read(buf)) != -1;) {
			            //Writes to this byte array output stream
			            bos.write(buf, 0, readNum);         
			        }
			
				byte[] bytes = bos.toByteArray();
				mBluetoothService.writeData(bytes);
				bos.flush();
				bos.close();
				fis.close();
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
		/**********************************************************************************************************/
		//		int count;
//		try {
//			File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/otto/FRAME000.bmp");
//			FileInputStream fis = new FileInputStream(file);
//			int lengthOfFile = (int) file.length();
//    
//			ByteArrayOutputStream bos = new ByteArrayOutputStream();
//			byte[] buf = new byte[64];
//			long total = 0;
//
//
//			while((count = fis.read(buf)) != -1) {
//            //Writes to this byte array output stream
//				total += count;
//    	
//				publishProgress((int) ((total * 100) / lengthOfFile));
//				bos.write(buf, 0, count);
//				byte[] bytes = bos.toByteArray();
//				mBluetoothService.writeData(bytes);	
//            //System.out.println("read " + readNum + " bytes,");         
//        }
//			bos.flush();
//			bos.close();
//			fis.close();
//		}
//				catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return null;
//	}
	@Override
	protected void onProgressUpdate(Integer... values) {
		super.onProgressUpdate(values);
	}

	@Override
	protected void onPostExecute(Void result) {			
		super.onPostExecute(result);
		Toast.makeText(getApplicationContext(), ListForActivity.FileName + "UPLOAD COMPLETE", Toast.LENGTH_SHORT).show();   
		mProgressDialog.dismiss();
		

	}
}
//	public void IMG() throws IOException {
//	/**********************************************************************************************************/
//    File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/otto/FRAME000.bmp");
//    FileInputStream fis = new FileInputStream(file);
//    
//    ByteArrayOutputStream bos = new ByteArrayOutputStream();
//    byte[] buf = new byte[64];
//
//    for (int readNum; (readNum = fis.read(buf)) != -1;) {
//            //Writes to this byte array output stream
//            bos.write(buf, 0, readNum); 
//            //System.out.println("read " + readNum + " bytes,");         
//        }
//
//	byte[] bytes = bos.toByteArray();
//	mBluetoothService.writeData(bytes);	
//  	}
//  int head=0;
//  int tale = 64;
    
//    for (int j=0; j< (int)Math.ceil((bytes.length/(double)64)); j++) {
//      if (tale > bytes.length) tale = bytes.length;
//      for (int i = head; i< tale; i++)
//	  {
//	  	output.write((int)bytes[i] & 0xFF);
//	    output.flush();	
//	  }
//      head = tale;
//      tale+=64;
//	 }
		  
//   }
	/**********************************************************************************************************/

	// The action listener for the EditText widget, to listen for the return key
	private TextView.OnEditorActionListener mWriteListener =
			new TextView.OnEditorActionListener() {
		public boolean onEditorAction(TextView view, int actionId, KeyEvent event) {
			// If the action is a key-up event on the return key, send the message
			if (actionId == EditorInfo.IME_NULL && event.getAction() == KeyEvent.ACTION_UP) {
				String message = view.getText().toString();
				sendMessage(message);
			}
			return true;
		}
	};

	// The Handler that gets information back from the BluetoothService
	private final Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MESSAGE_STATE_CHANGE:
				switch (msg.arg1) {
				case BluetoothChatService.STATE_CONNECTED:
					connected = true;
					//                        mTitle.setText(mConnectedDeviceName);
					break;
				case BluetoothChatService.STATE_CONNECTING:
					//                        mTitle.setText(R.string.title_connecting);
					break;
				case BluetoothChatService.STATE_NONE:
					connected = false;
					//                        mTitle.setText(R.string.title_not_connected);
					break;
				}
				//				onBluetoothStateChanged();
				break;
			case MESSAGE_WRITE:
				byte[] writeBuf = (byte[]) msg.obj;
				// construct a string from the buffer
				String writeMessage = new String(writeBuf);
				mConversationArrayAdapter.add(">>> " + writeMessage);
				break;
			case MESSAGE_READ:
				if (paused) break;
				byte[] readBuf = (byte[]) msg.obj;
				// construct a string from the valid bytes in the buffer
				String readMessage = new String(readBuf, 0, msg.arg1);
				mConversationArrayAdapter.add(readMessage);
				break;
			case MESSAGE_DEVICE_NAME:
				// save the connected device's name
				mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
				Toast.makeText(getApplicationContext(), "Connected to "
						+ mConnectedDeviceName, Toast.LENGTH_SHORT).show();
				break;
			case MESSAGE_TOAST:
				Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST),
						Toast.LENGTH_SHORT).show();
				break;
			}
		}
	};

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case REQUEST_CONNECT_DEVICE:
			// When DeviceListActivity returns with a device to connect
			if (resultCode == Activity.RESULT_OK) {
				// Get the device MAC address
				String address = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
				// Get the BLuetoothDevice object
				BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
				// Attempt to connect to the device
				mBluetoothService.connect(device);
			}
			break;

		case REQUEST_ENABLE_BT:
			// When the request to enable Bluetooth returns
			if (resultCode != Activity.RESULT_OK) {
				// User did not enable Bluetooth or an error occurred
				Toast.makeText(getApplicationContext(), "BT NOT ON", Toast.LENGTH_SHORT).show();
			}
			setupUserInterface();
		}
	}

	private void disconnectDevices() 
	{
		if (mBluetoothService != null) 
		{
			mBluetoothService.stop();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		this.getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}